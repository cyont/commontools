<?php

if (! defined('OX_MARKET_VAR_PATH')) {
    define('OX_MARKET_VAR_PATH', dirname(__FILE__));
    define('OX_MARKET_LIB_PATH', dirname(__FILE__) . '/../library');
    define('OX_MARKET_VAR_DICTIONARY', dirname(__FILE__) . '/data/dictionary/');    
}

?>